This folder contains ready-to-use prefabs:

- CameraLife and CameraMagic adds to your scene a Liquid Volume object plus a custom render camera - the animated image is available in the Render Textures called LifeRT and MagicRT which are found in the Textures folder. You can use these render textures in your game UI.

- SphereFlask: a spherical flask with liquid volume. Just drag and drop it into your scene. 

- BoxFlask and CylinderFlask: same but using Box and Cylinder shapes.
